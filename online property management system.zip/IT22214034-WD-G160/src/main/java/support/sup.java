package support;

public class sup { 
			private int id;  
			private String name,email,subject,massage;  
			public int getId() {  
			    return id;  
			}  
			public void setId(int id) {  
			    this.id = id;  
			}  
			public String getName() {  
			    return name;  
			}  
			public void setName(String name) {  
			    this.name = name;  
			}  
			public String getEmail() {  
			    return email;  
			}  
			public void setEmail(String email) {  
			    this.email = email;  
			}  
			public String getSubject() {  
			    return subject;  
			}  
			public void setSubject(String subject) {  
			    this.subject = subject;  
			}  
			public String getMassage() {  
			    return massage;  
			}  
			public void setMassage(String massage) {  
			    this.massage = massage;  
			}

}
